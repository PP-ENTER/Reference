from django.urls import path
from .views import PostListCreate, PostDetailUpdateDelete, PostDetailView

urlpatterns = [
    path('', PostListCreate.as_view(), name='post_list'),
    path('<int:pk>/', PostDetailUpdateDelete.as_view(), name='post_detail_update_delete'),
    # path('posts/<int:pk>/', PostDetailView.as_view(), name='post_detail'),
]
