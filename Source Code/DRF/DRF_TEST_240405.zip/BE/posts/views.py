from rest_framework import generics
from .models import Post
from .serializers import PostSerializer

# 생성
class PostListCreate(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer # serializers.py의 class 객체


# 세부내역 update, delete
class PostDetailUpdateDelete(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer


# 세부내역 조회
class PostDetailView(generics.RetrieveAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer