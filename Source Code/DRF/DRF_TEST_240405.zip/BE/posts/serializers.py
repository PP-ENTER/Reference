from rest_framework import serializers
from .models import Post

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ['id', 'title', 'description', 'image', 'created_at']
        # fields = '__all__' # 사용 금지

#         {
#             id : ycum
#             password : 12341234
#             title : 'test'
#         }


# 127.0.0.1:8000/accounts/