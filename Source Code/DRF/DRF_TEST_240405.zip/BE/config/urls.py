from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("posts/", include("posts.urls")),
    path("admin/", admin.site.urls),  # admin 페이지(일반적인 drf에서 사용하진 않습니다.)
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)